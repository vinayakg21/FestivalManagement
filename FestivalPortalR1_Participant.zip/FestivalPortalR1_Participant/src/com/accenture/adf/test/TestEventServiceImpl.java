package com.accenture.adf.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.accenture.adf.businesstier.entity.Event;
import com.accenture.adf.businesstier.entity.Visitor;
import com.accenture.adf.businesstier.service.EventServiceImpl;

/**
 * Junit test case to test class EventServiceImpl
 *
 */
public class TestEventServiceImpl {

	private List<Event> eventList;	
	private Visitor visitor;
	private EventServiceImpl eventServiceImpl;

	/**
	 * Set up the objects required before execution of every method
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {		
		eventServiceImpl = new EventServiceImpl();
		visitor = new Visitor();
		
	}

	/**
	 * Deallocates the objects after execution of every method
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {
		/**
		 * @TODO: Release all the objects here by assigning them null  
		 */
		visitor=null;
		eventServiceImpl=null;

	}

	/**
	 * Test case to test the method getAllEvents
	 */
	@Test
	public void testGetAllEvents() {
		/**
		 * @TODO: Call getAllEvents method and assert it for the size of returned array
		 */		
		eventList= eventServiceImpl.getAllEvents();
		assertEquals(6, eventList.size());
	
	}

	/**
	 * Test case to test the method checkEventsofVisitor
	 */
	@Test
	public void testCheckEventsofVisitor() {
		/**
		 * @TODO: Call checkEventsofVisitor and assert the returned type of this method
		 * for appropriate return type
		 */	
		visitor.setVisitorId(1001);
		boolean result= eventServiceImpl.checkEventsofVisitor(visitor, 1001);
		assertEquals(false, result);
		
	}

	/**
	 * Test case to test the method updateEventDeletions
	 */
	@Test
	public void testUpdateEventDeletions() {
		/**
		 * @TODO: Call updateEventDeletions and assert the return type of this method
		 * 
		 * 
		 */
		int seats1=0,seats2=0;
		 eventList = eventServiceImpl.getAllEvents();
		 for(Event event: eventList) {
			 if(event.getEventid()==1001) {
				 seats1 = event.getSeatsavailable();
			 }
		 }
		 eventServiceImpl.updateEventDeletions(1001);
		 
		 eventList = eventServiceImpl.getAllEvents();
		 for(Event event: eventList) {
			 if(event.getEventid()==1001) {
				 seats2 = event.getSeatsavailable();
			 }
		 }
		 
		 assertEquals((seats1),(seats2-1));
		 
	
		
	}

}
