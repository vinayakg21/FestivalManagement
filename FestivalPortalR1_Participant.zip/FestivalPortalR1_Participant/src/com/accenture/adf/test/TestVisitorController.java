package com.accenture.adf.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.web.servlet.ModelAndView;

import com.accenture.adf.businesstier.controller.VisitorController;
import com.accenture.adf.businesstier.dao.VisitorDAO;
import com.accenture.adf.businesstier.entity.Visitor;

/**
 * Junit test case to test the class VisitorController
 *
 */
public class TestVisitorController {

	private MockHttpServletRequest request;
	private MockHttpServletResponse response;
	private MockHttpSession session;
	private ModelAndView modelAndView;
	private VisitorController controller;
	private VisitorDAO visitorDao;

	/**
	 * Set up initial methods required before execution of every method
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		modelAndView = new ModelAndView();
		controller = new VisitorController();
		session = new MockHttpSession();
		response = new MockHttpServletResponse();
		visitorDao = new VisitorDAO();
	}

	/**
	 * Deallocate objects after execution of every method
	 * 
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {
		/**
		 * @TODO: Release all the objects here by assigning them null
		 */
		modelAndView=null;
		controller=null;
		session=null;
		response=null;
		visitorDao=null;
	}

	/**
	 * Positive test case to test the method newVisitor
	 */
	@Test
	public void testNewVisitor_Positive() {
		try {
			request = new MockHttpServletRequest("GET", "/newVistor.htm");

			request.setParameter("USERNAME", "bsmith");
			request.setParameter("PASSWORD", "password");
			request.setParameter("FIRSTNAME", "Bob");
			request.setParameter("LASTNAME", "Smith");
			request.setParameter("EMAIL", "bsmith@email.com");
			request.setParameter("PHONENO", "748937486");
			request.setParameter("ADDRESS", "USA");
			modelAndView = controller.newVisitor(request, response);
		} catch (Exception exception) {
			fail("Exception");
		}
		assertEquals("/registration.jsp", modelAndView.getViewName());
	}

	/**
	 * Negative test case to test the method newVisitor
	 */
	@Test
	public void testNewVisitor_Negative() {
		/**
		 * @TODO: Call newVisitor method by passing request object as null and asserting
		 *        the model view name
		 */

		try {
			modelAndView = controller.newVisitor(null, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			assertEquals("Error in Transaction, Please re-Try. for more information check Logfile in C:\\FERSLOG folder", e.getMessage());
		}

		assertEquals(null, modelAndView.getViewName());

	}

	/**
	 * Positive test case to test the method searchVisitor
	 */
	@Test
	public void testSearchVisitor_Positive() {
		/**
		 * @TODO: Create MockHttpServletRequest object Set request parameters for
		 *        USERNAME and PASSWORD for valid values Call searchVisitor method and
		 *        assert model view name
		 */

		request = new MockHttpServletRequest("GET", "/searchVisitor.htm");
		request.setParameter("USERNAME", "bsmith");
		request.setParameter("PASSWORD", "password");
		try {
			modelAndView = controller.searchVisitor(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		assertEquals("/visitormain.jsp", modelAndView.getViewName());
	}

	/**
	 * Negative test case of invalid user for method searchVisitor
	 */
	@Test
	public void testSearchVisitor_Negative_InvalidUser() {
		/**
		 * @TODO: Create MockHttpServletRequest object Set request parameters for
		 *        USERNAME and PASSWORD for invalid values Call searchVisitor method and
		 *        assert model view name
		 */
		request = new MockHttpServletRequest("GET", "/searchVisitor.htm");
		request.setParameter("USERNAME", "bsmith");
		request.setParameter("PASSWORD", "122");
		try {
			modelAndView = controller.searchVisitor(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		assertEquals("/index.jsp", modelAndView.getViewName());
	}

	/**
	 * Negative test case for method searchVisitor
	 */
	@Test
	public void testSearchVisitor_Negative() {
		/**
		 * @TODO: Call searchVisitor method by passing request object as null and
		 *        asserting the model view name
		 */
		try {
			modelAndView = controller.searchVisitor(null, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			assertEquals("Error in Transaction, Please re-Try. for more information check Logfile in C:\\FERSLOG folder", e.getMessage());
		}

		assertEquals(null, modelAndView.getViewName());

	}

	/**
	 * Positive test case for method registerVisitor
	 */
	@Test
	public void testRegisterVisitor_Positive() {
		/**
		 * @TODO: Create MockHttpServletRequest object Set visitor object in VISITOR
		 *        session by calling searchUser method from visitorDAO Set request
		 *        parameters for USERNAME and PASSWORD for valid values Call
		 *        registerVisitor method and assert model view name
		 * 
		 */

		request = new MockHttpServletRequest("GET", "/newVistor.htm");
		Visitor visitor;
		
		try {
			visitor = visitorDao.searchUser("bsmith", "password");
			session.setAttribute("VISITOR", visitor);
			request.setSession(session);
			
			request.setParameter("USERNAME", "bsmith");
			request.setParameter("PASSWORD", "password");
			request.setParameter("eventId", "1001");
			
			
			try {
				modelAndView = controller.registerVisitor(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		assertEquals("/visitormain.jsp", modelAndView.getViewName());
	}

	/**
	 * Negaative test case for method registerVisitor
	 */
	@Test
	public void testRegisterVisitor_Negative() {
		/**
		 * @TODO: Call registerVisitor method by passing request object as null and
		 *        asserting the model view name
		 */
		try {
			modelAndView = controller.registerVisitor(null, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			assertEquals("Error in Transaction, Please re-Try. for more information check Logfile in C:\\FERSLOG folder", e.getMessage());
		}
		
		assertEquals(null, modelAndView.getViewName());
		
	}

	/**
	 * Positive test case for method updateVisitor
	 */
	@Test
	public void testUpdateVisitor_Positive() {
		/**
		 * @TODO: Create MockHttpServletRequest object Set visitor object in VISITOR
		 *        session by calling searchUser method from visitorDAO Set request
		 *        parameters for all valid user values Call updateVisitor method and
		 *        assert model view name
		 */
		
		
		

		request = new MockHttpServletRequest("GET", "/updatevisitor.htm");
		Visitor visitor;
		
		try {
			visitor = visitorDao.searchUser("bsmith", "password");
			session.setAttribute("VISITOR", visitor);
			request.setSession(session);
			
			request.setParameter("USERNAME", "bsmith");
			request.setParameter("PASSWORD", "password");
			
				
				request.setParameter("visitorid", "1001");
				request.setParameter("username","bsmith");
				request.setParameter("password", "password");
				request.setParameter("firstname", "Bob");
				request.setParameter("lastname", "Smith");
				request.setParameter("email", "bsmith@email.com");
				request.setParameter("phonenumber", "748937486");
				request.setParameter("address", "USA");
				modelAndView = controller.updateVisitor(request, response);
				
			

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 

		assertEquals("/updatevisitor.jsp", modelAndView.getViewName());

		
		
		
		
	}

	/**
	 * Negative test case for method updateVisitor
	 */
	@Test
	public void testUpdateVisitor_Negative() {
		/**
		 * @TODO: Call updateVisitor method by passing request object as null and
		 *        asserting the model view name
		 */
		
		
		try {
			modelAndView = controller.updateVisitor(null, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			assertEquals("Error in Transaction, Please re-Try. for more information check Logfile in C:\\FERSLOG folder", e.getMessage());
		}
		assertEquals(null, modelAndView.getViewName());
		
		
		
	}

	/**
	 * Positive test case for method unregisterEvent
	 */
	@Test
	public void testUnregisterEvent_Positive() {
		/**
		 * @TODO: Create MockHttpServletRequest object Set visitor object in VISITOR
		 *        session by calling searchUser method from visitorDAO Set request
		 *        parameters for all USERNAME, PASSWORD and eventId values Call
		 *        unregisterEvent method and assert model view name
		 */
		request = new MockHttpServletRequest("GET", "/eventunreg.htm");
		Visitor visitor;
		
		try {
			visitor = visitorDao.searchUser("ylee", "password");
			session.setAttribute("VISITOR", visitor);
			request.setSession(session);
			
			request.setParameter("USERNAME", "bsmith");
			request.setParameter("PASSWORD", "password");
			request.setParameter("eventId", "1001");
			try {
				modelAndView = controller.unregisterEvent(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		assertEquals("/visitormain.jsp", modelAndView.getViewName());

		
	}

	/**
	 * Negative test case for method unregisterEvent
	 */
	@Test
	public void testUnregisterEvent_Negative() {
		/**
		 * @TODO: Call unregisterEvent method by passing request object as null and
		 *        asserting the model view name
		 */
		try {
			modelAndView = controller.unregisterEvent(null, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			assertEquals("Error in Transaction, Please re-Try. for more information check Logfile in C:\\FERSLOG folder", e.getMessage());
		}
		
		
		assertEquals(null, modelAndView.getViewName());

		
		
	}

	
}
