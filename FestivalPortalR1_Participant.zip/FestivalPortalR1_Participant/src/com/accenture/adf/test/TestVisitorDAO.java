package com.accenture.adf.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.accenture.adf.businesstier.dao.EventDAO;
import com.accenture.adf.businesstier.dao.VisitorDAO;
import com.accenture.adf.businesstier.entity.Event;
import com.accenture.adf.businesstier.entity.Visitor;

/**
 * JUnit test case for VisitorDAO class for testing all repository methods to
 * call database sub-routines
 * 
 */
public class TestVisitorDAO {
	
	private Visitor visitor;
	private VisitorDAO visitorDAO;
	private EventDAO eventDAO;
	private ArrayList<Event> registeredEvents;

	/**
	 * Setting up initial objects 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		visitor = new Visitor();
		visitorDAO = new VisitorDAO();
		registeredEvents = new ArrayList<Event>();
	}

	/**
	 * Deallocating objects after execution of every method
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {
		/**
		 * @TODO: Release all the objects here by assigning them null  
		 */
		visitor = null;
		visitorDAO = null;
		registeredEvents = null;
	}

	/**
	 * Test case for method insertData
	 */
	@Test
	public void testInsertData() {
		/**
		 * @TODO: Create visitor object by setting appropriate values
		 * Call insertData method by passing this visitor object
		 * Search this new visitor object by calling searchUser method
		 * Assert the values of username
		 */		
		visitor=new Visitor();
		visitor.setUserName("vinayak");
		visitor.setPassword("password");
		visitor.setFirstName("Vinayak");
		visitor.setLastName("Gawde");
		visitor.setEmail("vinayak@email.com");
		visitor.setPhoneNumber("989898");
		visitor.setAddress("Mumbai");
		try {
			visitorDAO.insertData(visitor);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			
		Visitor v1= visitorDAO.searchUser("vinayak", "password");
		assertEquals(visitor.getUserName(),v1.getUserName());
		
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}	

	/**
	 * Test case for method searchUser
	 */
	@Test
	public void testSearchUser() {
		/**
		 * @TODO: Call searchUser method for valid values of username
		 * and password and assert the value of username for the returned type of method
		 */		
		try {
			visitor=visitorDAO.searchUser("vinayak", "password");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals("vinayak",visitor.getUserName());
		assertEquals("password",visitor.getPassword());
		
	}

	/**
	 * Test case for method registerVisitorToEvent
	 */
	@Test
	public void testRegisterVisitorToEvent() {
		/**
		 * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
		 * Pass this visitor object and valid eventid to registerVisitorToEvent method
		 * and assert the value
		 */		
		try {
				Visitor v= visitorDAO.searchUser("vinayak", "password");				
				int before = visitorDAO.registeredEvents(v).size();
				
				visitorDAO.registerVisitorToEvent(v,1001);
					
				int after = visitorDAO.registeredEvents(v).size();
					
				assertEquals(before+1, after);
		} catch (Exception e) {
					
			assertEquals(null, e.getMessage());
			
		}
			
			
			
			/**
			 * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
			 * Pass this visitor object and valid eventid to registerVisitorToEvent method
			 * and assert the value
			 */		
		}	

		/**
		 * Test case for method registeredEvents
		 */
			@Test
			public void testRegisteredEvents() {
				
			try {
				visitor= visitorDAO.searchUser("vinayak","password");
				int size = visitorDAO.registeredEvents(visitor).size();
				assertTrue(size>0);
			} catch (ClassNotFoundException e) {
				fail("not correct");
			} catch (SQLException e) {
				fail("not correct");
			}
			/**
			 * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
			 * Pass this visitor object and valid eventid to registeredEvents method
			 * and assert the value
			 */ catch (Exception e) {
				// TODO Auto-generated catch block
				 assertEquals(null, e.getMessage());
			 }		
		}


	/**
	 * Test case for method registeredEvents
	 */
	/**
	 * Test case for method updateVisitor
	 */
	@Test
	public void testUpdateVisitor() {
		/**
		 * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
		 * Update the value in this visitor object
		 * Pass this visitor object to updateVisitor method
		 * and assert the value of changed value
		 */		

		try {
			visitor=visitorDAO.searchUser("vinayak", "password");
			visitor.setFirstName("Vinayak");
			visitor.setLastName("Gawde");
			visitor.setUserName("vinayak");		
			visitor.setEmail("bsmith@email.com");
			visitor.setPhoneNumber("454545");				
			visitor.setAddress("USA");			
			visitorDAO.updateVisitor(visitor);			
			
			assertEquals(1,visitorDAO.updateVisitor(visitor));
		} catch (ClassNotFoundException e) {
				
		} catch (SQLException e) {
				
		}
					
			
	
		
		
	}

	/**
	 * Test case for method registeredEvents
	 */
	@Test
	public void testUnregisterEvent() {
		

		try {
			visitor=visitorDAO.searchUser("vinayak", "password");
			
			int before = visitorDAO.registeredEvents(visitor).size();
			visitorDAO.unregisterEvent(visitor, 1001);	
			int after = visitorDAO.registeredEvents(visitor).size();			
						
			assertEquals(before-1, after);
			
		}  catch (Exception e) {
			
		}		
		
	}

	
	/**
	 * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
	 * Pass this visitor object and valid eventid to unregisterEvent method
	 * and assert the value
	 */		
	
	@Test
	public void testChangePassword() {
		
		try {
			Visitor visitor= new Visitor();
			visitor=visitorDAO.searchUser("bsmith", "password");
			assertEquals("password",visitor.getPassword());
		} catch (ClassNotFoundException e) {
			
		} catch (SQLException e) {
			
		}
		
		/**
		 * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
		 * Pass this visitor object and valid eventid to unregisterEvent method
		 * and assert the value
		 */		
		
	}
	
}
