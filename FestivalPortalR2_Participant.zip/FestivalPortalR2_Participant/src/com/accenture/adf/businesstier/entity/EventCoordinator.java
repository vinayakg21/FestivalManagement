package com.accenture.adf.businesstier.entity;

public class EventCoordinator extends People {

	private int eventcoordinatorid;
	private String places;
	
	public int getEventcoordinatorid() {
		return eventcoordinatorid;
	}

	public void setEventcoordinatorid(int eventcoordinatorid) {
		this.eventcoordinatorid = eventcoordinatorid;
	}

	public String getPlaces() {
		return places;
	}

	public void setPlaces(String places) {
		this.places = places;
	}
	
}
