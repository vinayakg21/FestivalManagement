package com.accenture.adf.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.accenture.adf.businesstier.entity.Event;
import com.accenture.adf.businesstier.entity.EventCoordinator;
import com.accenture.adf.businesstier.entity.Visitor;
import com.accenture.adf.businesstier.service.EventServiceImpl;
import com.accenture.adf.businesstier.service.VisitorServiceImpl;
import com.accenture.adf.exceptions.FERSGenericException;

/**
 * Junit test case to test class EventServiceImpl
 * 
 */
public class TestEventServiceImpl {

	private List<Object[]> eventList;
	private Visitor visitor;
	private EventServiceImpl eventServiceImpl;
	private VisitorServiceImpl visitorServiceImpl;
	private Event newevent;

	/**
	 * Set up the objects required before execution of every method
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		eventServiceImpl = new EventServiceImpl();
		visitor = new Visitor();
		visitorServiceImpl = new VisitorServiceImpl();
		newevent = new Event();
	}

	/**
	 * Deallocates the objects after execution of every method
	 * 
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {
		/**
		 * @TODO: Release all the objects here by assigning them null  
		 */
		eventServiceImpl = null;
		visitor = null;
		visitorServiceImpl = null;
		newevent = null;
	}

	/**
	 * Test case to test the method getAllEvents
	 */
	@Test
	public void testGetAllEvents() {
		/**
		 * @TODO: Call getAllEvents method and assert it for the size of returned array
		 */	
		int noOfEvents = eventServiceImpl.getAllEvents().size();
		assertTrue(noOfEvents>0);
	}

	/**
	 * Test case to test the method checkEventsofVisitor
	 */
	@Test
	public void testCheckEventsofVisitor() {
		/**
		 * @TODO: Call checkEventsofVisitor and assert the returned type of this method
		 * for appropriate return type
		 */	
		
		visitor = visitorServiceImpl.searchVisitor("bsmith", "password");
		assertEquals(false,eventServiceImpl.checkEventsofVisitor(visitor, 1001, 10001));
		
		
	}

	/**
	 * Test case to test the method updateEventDeletions
	 */
	@Test
	public void testUpdateEventDeletions() {
		/**
		 * @TODO: Call updateEventDeletions and assert the return type of this method
		 */	
		
		visitor = visitorServiceImpl.searchVisitor("bsmith", "password");
		visitor.setAddress("Mumbai");
		assertEquals(1, visitorServiceImpl.updateVisitorDetails(visitor));
		
	}

	/**
	 * Junit test case for getEventCoordinator
	 */
	@Test
	public void testGetEventCoordinator() {
		/**
		 * @TODO: Call getAllEventCoordinators and assert the size of return type of this method
		 */		
		int noOfEventCoordinators = eventServiceImpl.getAllEventCoordinators().size();
		assertTrue(noOfEventCoordinators>0);
	}

	/**
	 * Junit test case for getEvent
	 */
	@Test
	public void testGetEvent() {
		/**
		 * @TODO: Call getEvent and assert the event id of this event with 
		 * passed event id 
		 */		
		int eventid = eventServiceImpl.getEvent(1001, 10001).getEventid();
		assertEquals(1001, eventid);
		
	}

	/**
	 * Junit test case for updateEvent
	 */
	@Test
	public void testInsertEvent() {
		/**
		 * @TODO: Call insertEvent
		 * Create event object by setting appropriate values
		 * Assert the status of insertEvent method
		 */		
		
		newevent.setName("World Tour");
		newevent.setDescription("7 wonders Tour");
		newevent.setPlace("World");
		newevent.setDuration("1200-2500");
		newevent.setEventtype("Tour");
		newevent.setSeatsavailable("2000");
		newevent.setEventCoordinatorId(101);
		newevent.setEventSession(2);
		
		int noOfRecordsInserted = eventServiceImpl.insertEvent(newevent);
		assertEquals(1, noOfRecordsInserted);
	}

	/**
	 * Junit test case for updateEvent
	 */
	@Test
	public void testUpdateEvent() {
		/**
		 * @TODO: Fetch Event object by calling getAllEvents method 
		 * Update event object by setting appropriate values
		 * Call updateEvent method
		 * Assert the status of updateEvent method
		 */	
		
		newevent.setEventid(1001);
		newevent.setName("Rose Parade");
		newevent.setDescription("Floats, Music and More");
		newevent.setPlace("Rose Garden");
		newevent.setDuration("1200-2500");
		newevent.setEventtype("Tour");
		newevent.setSeatsavailable("2000");
		newevent.setSessionId(10001);
		
		int noOfRecordsUpdated = eventServiceImpl.updateEvent(newevent);
		
		assertEquals(1, noOfRecordsUpdated );

	}

	/**
	 * Junit test case for deleteEvent
	 */
	@Test
	public void testDeleteEvent() {
		/**
		 * @TODO: Fetch Event object by calling getAllEvents method 
		 * Update event object by setting appropriate values
		 * Call deleteEvent method
		 * Assert the status of deleteEvent method
		 */	
	
		
		int noOfRecordsDeleted = eventServiceImpl.deleteEvent(1004, 10004);
		assertEquals(1, noOfRecordsDeleted);
		
	}

}
