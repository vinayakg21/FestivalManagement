package com.accenture.adf.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.accenture.adf.businesstier.dao.VisitorDAO;
import com.accenture.adf.businesstier.entity.Visitor;

import junit.framework.Assert;

/**
 * JUnit test case for VisitorDAO class for testing all repository methods to
 * call database sub-routines
 * 
 */
public class TestVisitorDAO {

	private Visitor visitor;
	private VisitorDAO visitorDAO;
	private ArrayList<Object[]> registeredEvents;

	/**
	 * Setting up initial objects
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		visitor = new Visitor();
		visitorDAO = new VisitorDAO();
		registeredEvents = new ArrayList<Object[]>();
	}

	/**
	 * Deallocating objects after execution of every method
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {
		/**
		 * @TODO: Release all the objects here by assigning them null  
		 */
		visitor=null;
		visitorDAO=null;
		registeredEvents=null;
	}

	/**
	 * Test case for method insertData
	 */
	@Test
	public void testInsertData() {
		/**
		 * @TODO: Create visitor object by setting appropriate values
		 * Call insertData method by passing this visitor object
		 * Search this new visitor object by calling searchUser method
		 * Assert the values of username
		 */		
		visitor.setUserName("vinayak");
		visitor.setPassword("password");
		visitor.setFirstName("Vinayak");
		visitor.setLastName("Gawde");
		visitor.setEmail("vgawde@gmail.com");
		visitor.setPhoneNumber("565656");
		visitor.setAddress("Mumbai");
		try {
			visitorDAO.insertData(visitor);
			assertEquals(visitor.getUserName(), visitorDAO.searchUser("vinayak", "password").getUserName());
		} catch (Exception e) {
			// TODO Auto-generated catch block
		}
	}	

	/**
	 * Test case for method searchUser
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	@Test
	public void testSearchUser() throws ClassNotFoundException, SQLException {
		/**
		 * @TODO: Call searchUser method for valid values of username
		 * and password and assert the value of username for the returned type of method
		 */		
		try {
			visitorDAO.searchUser("vinayak", "password");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals("vinayak",visitorDAO.searchUser("vinayak", "password").getUserName());
	}

	/**
	 * Test case for method registerVisitorToEvent
	 * @throws Exception 
	 */
	@Test
	public void testRegisterVisitorToEvent() throws Exception {
		/**
		 * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
		 * Pass this visitor object and valid eventid to registerVisitorToEvent method
		 * and assert the value
		 */		
		try {
			visitor=visitorDAO.searchUser("vinayak", "password");
			int before=visitorDAO.registeredEvents(visitor).size();
			visitorDAO.registerVisitorToEvent(visitor, 1002, 10002);
			int after=visitorDAO.registeredEvents(visitor).size();
			assertEquals(before+1, after);
		} catch (Exception e) {
			// TODO Auto-generated catch block
		
		}
	}	

	/**
	 * Test case for method registeredEvents
	 */
	@Test
	public void testRegisteredEvents() {
		/**
		 * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
		 * Pass this visitor object and valid eventid to registeredEvents method
		 * and assert the value
		 */		
		try {
			visitor= visitorDAO.searchUser("vinayak", "password");
			registeredEvents=visitorDAO.registeredEvents(visitor);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			
		}
		
		assertEquals(false, registeredEvents.isEmpty());
	}

	/**
	 * Test case for method updateVisitor
	 */
	@Test
	public void testUpdateVisitor() {
		/**
		 * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
		 * Update the value in this visitor object
		 * Pass this visitor object to updateVisitor method
		 * and assert the value of changed value
		 */		
		try {
			visitor= visitorDAO.searchUser("vinayak", "password");
			Visitor visitor1= new Visitor();
			visitor.setPhoneNumber("123456");
		   assertEquals(1, visitorDAO.updateVisitor(visitor));
		} catch (Exception e) {
			
		}
	}

	/**
	 * Test case for method registeredEvents
	 * @throws Exception 
	 */
	@Test
	public void testUnregisterEvent() throws Exception {
		/**
		 * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
		 * Pass this visitor object and valid eventid to unregisterEvent method
		 * and assert the value
		 */		
		
		
		try {
			visitor= visitorDAO.searchUser("vinayak", "password");
			int before = visitorDAO.registeredEvents(visitor).size();
			visitorDAO.unregisterEvent(visitor, 1002, 10002);
			int after = visitorDAO.registeredEvents(visitor).size();
			assertEquals(before-1,after);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
		}
		
	}
	
	/**
	 * Test case for method change password
	 */
	@Test
	public void testChangePassword_VisitorNull() {
		try {
			visitor = null;
			visitorDAO.changePassword(visitor);
		} catch (SQLException exception) {
			fail("SQL Exception");
		} catch (ClassNotFoundException exception) {
			fail("Class Not Found Exception");
		} catch (Exception exception) {
			fail("NULL Exception");
		}
	}

}
