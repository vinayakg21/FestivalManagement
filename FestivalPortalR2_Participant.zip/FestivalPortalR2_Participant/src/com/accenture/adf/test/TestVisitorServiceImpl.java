package com.accenture.adf.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.accenture.adf.businesstier.entity.Event;
import com.accenture.adf.businesstier.entity.Visitor;
import com.accenture.adf.businesstier.service.EventServiceImpl;
import com.accenture.adf.businesstier.service.VisitorServiceImpl;

/**
 * Junit test class for VisitorServiceImpl
 *
 */
public class TestVisitorServiceImpl {

	private List<Event> visitorList;	
	private Visitor visitor;
	private VisitorServiceImpl visitorServiceImpl;
	private EventServiceImpl eventServiceImpl;
	

	/**
	 * Set up the initial methods 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {		
		visitorServiceImpl = new VisitorServiceImpl();
		visitor = new Visitor();
		eventServiceImpl = new EventServiceImpl();
	}

	/**
	 * Deallocates the objects after execution of every method
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {
		/**
		 * @TODO: Release all the objects here by assigning them null  
		 */
		visitorServiceImpl = null;
		visitor = null;
		eventServiceImpl = null;
	}

	/**
	 * Test case for method createVisitor
	 */
	@Test
	public void testCreateVisitor() {
		/**
		 * @TODO: Set the appropriate values for visitor object and
		 * call the method createVisitor by passing an argument of this visitor 
		 * object and then asserting the returned type of this method
		 */		
		visitor.setUserName("pratik");
		visitor.setPassword("password");
		visitor.setFirstName("Pratik");
		visitor.setLastName("Mori");
		visitor.setEmail("mori@gmail.com");
		visitor.setPhoneNumber("121212");
		visitor.setAddress("Gujarat");
		
		boolean result = visitorServiceImpl.createVisitor(visitor);
		
		assertEquals(true, result);
	}

	/**
	 * Test case for method createVisitor
	 */
	@Test
	public void testSearchVisitor() {
		/**
		 * @TODO: Call searchVisitor method by passing the appropriate arguments 
		 * and then asserting the returned type visitor username with the argument passed
		 */		
		
		visitor = visitorServiceImpl.searchVisitor("pratik", "password");
		
		assertEquals("pratik", visitor.getUserName());
		
	}

	/**
	 * Test case for method RegisterVisitor
	 */
	@Test
	public void testRegisterVisitor() {
		/**
		 * @TODO: Call RegisterVisitor method by passing visitor object which 
		 * can be retrieved using searchVisitor method and then asserting the returned
		 * type of RegisterVisitor method 
		 */		
		
		visitor = visitorServiceImpl.searchVisitor("pratik", "password");
		
		int before = visitorServiceImpl.showRegisteredEvents(visitor).size();
		visitorServiceImpl.RegisterVisitor(visitor, 1003, 10003);
		int after = visitorServiceImpl.showRegisteredEvents(visitor).size();
		
		
		
		assertEquals(before+1, after);
	}

	/**
	 * Test case for method showRegisteredEvents
	 */
	@Test
	public void testShowRegisteredEvents() {
		/**
		 * @TODO: Call showRegisteredEvents method by passing visitor object which 
		 * can be retrieved using searchVisitor method and then asserting the returned
		 * type of showRegisteredEvents method 
		 */		
		
		visitor = visitorServiceImpl.searchVisitor("pratik", "password");
		
		int noOfEventsRegistered = visitorServiceImpl.showRegisteredEvents(visitor).size();
		
		assertTrue(noOfEventsRegistered>0);
		
	}

	/**
	 * Test case for method updateVisitorDetails
	 */
	@Test
	public void testUpdateVisitorDetails() {
		/**
		 * @TODO: Call updateVisitorDetails method by passing the visitor object which
		 * can be retrieved using searchVisitor method and then asserting the returned
		 * type of updateVisitorDetails
		 */		
		visitor = visitorServiceImpl.searchVisitor("pratik", "password");
		visitor.setAddress("UK");
		int noOfRowsUpdated = visitorServiceImpl.updateVisitorDetails(visitor);
		assertEquals(1, noOfRowsUpdated);
		
	}

	/**
	 * Test case for method unregisterEvent
	 */
	@Test
	public void testUnregisterEvent() {
		/**
		 * @TODO: Call unregisterEvent method by passing the visitor object which can be
		 * retrieved using searchVisitor method and then asserting the returned type 
		 * of unregisterEvent
		 */		
		visitor = visitorServiceImpl.searchVisitor("pratik", "password");
		int sizeBefore = visitorServiceImpl.showRegisteredEvents(visitor).size();		
		
		visitorServiceImpl.unregisterEvent(visitor, 1003, 10003);
		
		int sizeAfter = visitorServiceImpl.showRegisteredEvents(visitor).size();
		
		assertEquals(sizeBefore-1,sizeAfter);
		
	}

}
